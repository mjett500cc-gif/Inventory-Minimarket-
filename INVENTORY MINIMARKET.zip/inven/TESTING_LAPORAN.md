# 📋 BLACKBOX TESTING - SISTEM LAPORAN INVENTORY

**Aplikasi**: Inventory Minimarket Mjet  
**Tanggal Testing**: 2026-06-09  
**Status**: Ready for Production

---

## 1️⃣ LAPORAN MASUK EXCEL (laporan_masuk_excel.php)

### 1.1 Test Case: Akses Tanpa Filter
**Tujuan**: Memastikan laporan default menampilkan semua barang masuk  
**Langkah**:
1. Buka halaman masuk.php
2. Klik tombol "Export Excel"
3. File download secara otomatis

**Expected Result**:
- ✅ File `Laporan_Barang_Masuk.xls` berhasil diunduh
- ✅ Kolom: No, No Transaksi, Tanggal Masuk, Kode Barang, Nama Barang, Jumlah, Harga Satuan, Total Harga, Supplier (9 kolom)
- ✅ Jumlah menampilkan format merged: "10 box", "5 karton", "100 pcs", dll
- ✅ Semua data barang masuk ditampilkan dalam urutan terbaru dulu
- ✅ Total Nilai Barang Masuk ditampilkan dengan format Rp

### 1.2 Test Case: Filter Dengan Tanggal
**Tujuan**: Memastikan filter tanggal berfungsi  
**Langkah**:
1. Di halaman masuk.php, isi field "Dari" dengan tanggal awal (misal: 2024-01-01)
2. Isi field "Sampai" dengan tanggal akhir (misal: 2024-12-31)
3. Klik Filter
4. Klik Export Excel

**Expected Result**:
- ✅ Hanya data barang masuk dalam rentang tanggal yang ditampilkan
- ✅ Total nilai dihitung ulang sesuai filter

### 1.3 Test Case: Filter Dengan Pencarian
**Tujuan**: Memastikan pencarian bekerja  
**Langkah**:
1. Di halaman masuk.php, ketik keyword di search box (misal: "BM-" untuk nomor transaksi)
2. Tekan Enter atau klik Filter
3. Klik Export Excel

**Expected Result**:
- ✅ Hanya data yang cocok dengan pencarian ditampilkan
- ✅ Pencarian mencakup: No Transaksi, Nama Barang, Supplier, Keterangan

### 1.4 Test Case: Filter Tanggal + Pencarian
**Tujuan**: Memastikan kombinasi filter bekerja  
**Langkah**:
1. Isi pencarian dan tanggal sekaligus
2. Klik Filter
3. Klik Export Excel

**Expected Result**:
- ✅ Hanya data yang sesuai KEDUA filter ditampilkan
- ✅ Total nilai yang ditampilkan adalah total dari data yang ter-filter

### 1.5 Test Case: Data Kosong
**Tujuan**: Memastikan laporan handle data tidak ada dengan baik  
**Langkah**:
1. Filter dengan keyword yang tidak ada di database
2. Klik Filter
3. Klik Export Excel

**Expected Result**:
- ✅ File tetap diunduh
- ✅ Menampilkan header tapi tanpa data
- ✅ Total nilai = Rp 0 atau kosong
- ✅ Pesan "Tidak ada data untuk ditampilkan" ditampilkan

### 1.6 Test Case: Format Currency
**Tujuan**: Memastikan format uang benar  
**Langkah**:
1. Export Excel tanpa filter
2. Buka file di Excel
3. Lihat kolom Harga Satuan dan Total Harga

**Expected Result**:
- ✅ Format: Rp X.XXX.XXX,XX (dengan titik sebagai pemisah ribuan dan koma untuk desimal)
- ✅ Tidak ada value yang hilang

---

## 2️⃣ LAPORAN KELUAR EXCEL (laporan_keluar_excel.php)

### 2.1 Test Case: Akses Tanpa Filter
**Tujuan**: Memastikan laporan default menampilkan semua barang keluar  
**Langkah**:
1. Buka halaman keluar.php
2. Klik tombol "Export Excel"
3. File download secara otomatis

**Expected Result**:
- ✅ File `Laporan_Barang_Keluar.xls` berhasil diunduh
- ✅ Kolom: No, No Transaksi, Tanggal Keluar, Kode Barang, Nama Barang, Jumlah, Harga Satuan, Total Harga, Tujuan, Penerima (10 kolom)
- ✅ Jumlah menampilkan format merged: "10 box", "5 karton", "100 pcs", dll
- ✅ Semua data barang keluar ditampilkan dalam urutan terbaru dulu
- ✅ Total Nilai Barang Keluar ditampilkan dengan format Rp

### 2.2 Test Case: Filter Dengan Tanggal
**Tujuan**: Memastikan filter tanggal berfungsi  
**Langkah**:
1. Di halaman keluar.php, isi field tanggal
2. Klik Filter
3. Klik Export Excel

**Expected Result**:
- ✅ Hanya data dalam rentang tanggal ditampilkan
- ✅ Total nilai dihitung ulang

### 2.3 Test Case: Filter Dengan Pencarian
**Tujuan**: Memastikan pencarian bekerja  
**Langkah**:
1. Ketik keyword di search box (misal: "Store A" untuk tujuan)
2. Klik Filter
3. Klik Export Excel

**Expected Result**:
- ✅ Pencarian mencakup: No Transaksi, Nama Barang, Tujuan, Keterangan

### 2.4 Test Case: Kolom Penerima
**Tujuan**: Memastikan kolom penerima ditampilkan dengan baik  
**Langkah**:
1. Export Excel
2. Buka file

**Expected Result**:
- ✅ Kolom Penerima ditampilkan
- ✅ Jika kosong, menampilkan "-"

### 2.5 Test Case: Format Data
**Tujuan**: Memastikan semua format data benar  
**Langkah**:
1. Export dan lihat file Excel

**Expected Result**:
- ✅ Tanggal format: DD-MM-YYYY
- ✅ Currency format: Rp X.XXX.XXX,XX
- ✅ Jumlah tanpa format khusus (plain number)

---

## 3️⃣ LAPORAN INVENTORY EXCEL (laporan_excel.php)

### 3.1 Test Case: Akses Laporan Bulanan
**Tujuan**: Memastikan laporan ringkasan bulanan berfungsi  
**Langkah**:
1. Buka halaman laporan.php
2. Pilih bulan dan tahun
3. Klik Filter
4. Klik tombol "Excel"

**Expected Result**:
- ✅ File `Laporan_Inventory_MM_YYYY.xls` berhasil diunduh
- ✅ Header: LAPORAN INVENTORY MINIMARKET Mjet
- ✅ Periode: [Bulan] [Tahun]

### 3.2 Test Case: Ringkasan Inventory
**Tujuan**: Memastikan ringkasan data benar  
**Langkah**:
1. Export Excel
2. Lihat section "RINGKASAN INVENTORY"

**Expected Result**:
- ✅ Total Jenis Barang = COUNT barang aktif
- ✅ Total Stok = SUM stok barang aktif
- ✅ Nilai Stok = SUM(stok * harga_beli) format Rp
- ✅ Semua nilai terisi (tidak boleh kosong atau 0 jika ada data)

### 3.3 Test Case: Transaksi Bulan Ini
**Tujuan**: Memastikan data transaksi bulan terfilter benar  
**Langkah**:
1. Pilih bulan dengan transaksi (misal Januari 2024)
2. Export Excel
3. Lihat section "TRANSAKSI BULAN INI"

**Expected Result**:
- ✅ Barang Masuk: Jumlah transaksi, total qty, total nilai
- ✅ Barang Keluar: Jumlah transaksi, total qty, total nilai
- ✅ Format currency: Rp X.XXX.XXX,XX
- ✅ Format qty: X.XXX dengan pemisah ribuan

### 3.4 Test Case: Stok Per Kategori
**Tujuan**: Memastikan data per kategori ditampilkan  
**Langkah**:
1. Export Excel
2. Lihat section "STOK PER KATEGORI"

**Expected Result**:
- ✅ Kolom: Kategori, Jumlah Item, Total Stok, Nilai Stok
- ✅ Semua kategori ditampilkan (termasuk yang stoknya 0)
- ✅ Nilai Stok format Rp

### 3.5 Test Case: Barang Paling Sering Keluar
**Tujuan**: Memastikan TOP 5 items ditampilkan  
**Langkah**:
1. Pilih bulan dengan minimal 5 transaksi keluar
2. Export Excel
3. Lihat section "BARANG PALING SERING KELUAR"

**Expected Result**:
- ✅ Menampilkan maksimal 5 barang
- ✅ Urutan: dari qty terbanyak ke terkecil
- ✅ Kolom: Kode Barang, Nama Barang, Total Keluar
- ✅ Jika kurang dari 5 transaksi, hanya menampilkan yang ada

### 3.6 Test Case: Bulan Tanpa Data
**Tujuan**: Memastikan laporan handle bulan tanpa transaksi  
**Langkah**:
1. Pilih bulan yang tidak ada transaksinya
2. Export Excel

**Expected Result**:
- ✅ File tetap diunduh
- ✅ Ringkasan tetap ditampilkan (data stok current)
- ✅ Transaksi bulan ini = 0
- ✅ Tidak error

---

## 4️⃣ LAPORAN INVENTORY PDF (laporan_pdf.php)

### 4.1 Test Case: Akses Laporan PDF
**Tujuan**: Memastikan PDF generation berfungsi  
**Langkah**:
1. Buka laporan.php
2. Pilih bulan dan tahun
3. Klik tombol "PDF"

**Expected Result**:
- ✅ File PDF berhasil di-generate
- ✅ Filename: Laporan_Inventory_MM_YYYY.pdf
- ✅ Format A4 Landscape
- ✅ PDF bisa dibuka dengan normal

### 4.2 Test Case: Isi PDF
**Tujuan**: Memastikan isi PDF sesuai  
**Langkah**:
1. Download PDF
2. Buka dengan PDF reader
3. Periksa setiap section

**Expected Result**:
- ✅ Judul: LAPORAN INVENTORY MINIMARKET MJET
- ✅ Periode terbaca dengan jelas
- ✅ Ringkasan Inventaris: Total Barang, Total Stok, Nilai Stok, Stok Menipis
- ✅ Barang Masuk & Keluar section terlihat
- ✅ Stok Per Kategori tabel tertampil
- ✅ Barang Paling Sering Keluar section ada (jika ada data)
- ✅ Barang Stok Menipis section ada (jika ada data)
- ✅ Tanggal print tertera di bawah

### 4.3 Test Case: Format Currency di PDF
**Tujuan**: Memastikan format Rp terlihat di PDF  
**Langkah**:
1. Download dan buka PDF
2. Lihat nilai-nilai di PDF

**Expected Result**:
- ✅ Semua nilai currency menampilkan "Rp" diikuti angka
- ✅ Angka terformat dengan pemisah ribuan

### 4.4 Test Case: Table Layout
**Tujuan**: Memastikan tabel rapi dan mudah dibaca  
**Langkah**:
1. Buka PDF
2. Lihat layout tabel

**Expected Result**:
- ✅ Border tabel terlihat jelas
- ✅ Header tabel punya background warna
- ✅ Font readable (DejaVu Sans 11px)
- ✅ Ukuran kertas A4 Landscape cukup untuk tampilan

---

## 5️⃣ INTEGRASI DENGAN HALAMAN MASUK & KELUAR

### 5.1 Test Case: Export dari masuk.php
**Tujuan**: Memastikan parameter filter dikirim ke laporan_masuk_excel.php  
**Langkah**:
1. Di masuk.php, isi pencarian dengan keyword
2. Isi tanggal Dari dan Sampai
3. Klik Filter
4. Klik tombol "Export Excel"

**Expected Result**:
- ✅ URL Excel button berisi parameter: ?q=xxx&dari=xxx&sampai=xxx
- ✅ File yang didownload sudah ter-filter sesuai parameter
- ✅ Data yang ditampilkan di Excel sama dengan yang ditampilkan di halaman

### 5.2 Test Case: Export dari keluar.php
**Tujuan**: Memastikan parameter filter dikirim ke laporan_keluar_excel.php  
**Langkah**:
1. Di keluar.php, isi pencarian dan tanggal
2. Klik Filter
3. Klik tombol "Export Excel"

**Expected Result**:
- ✅ URL Excel button berisi parameter filter
- ✅ File yang didownload sudah ter-filter
- ✅ Konsisten dengan data di halaman

### 5.3 Test Case: Export Tanpa Filter
**Tujuan**: Memastikan export bisa digunakan tanpa filter  
**Langkah**:
1. Buka masuk.php atau keluar.php
2. Langsung klik "Export Excel" tanpa filter
3. Check file

**Expected Result**:
- ✅ File didownload dengan semua data
- ✅ Tidak error meski tanpa parameter

---

## 6️⃣ VALIDASI DATA & INTEGRITAS

### 6.1 Test Case: SQL Injection Prevention
**Tujuan**: Memastikan query tidak rentan SQL injection  
**Langkah**:
1. Di search box masuk.php, ketik: `BM-001' OR '1'='1`
2. Klik Filter
3. Export Excel

**Expected Result**:
- ✅ Pencarian tetap bekerja normal (tidak return semua data)
- ✅ Menggunakan prepared statement (parameterized query)
- ✅ Tidak error

### 6.2 Test Case: XSS Prevention
**Tujuan**: Memastikan data user tidak inject script  
**Langkah**:
1. Di halaman masuk/keluar, lihat keterangan atau supplier yang mungkin berisi HTML
2. Export Excel

**Expected Result**:
- ✅ Data ditampilkan sebagai plain text
- ✅ Tidak ada script yang dijalankan

### 6.3 Test Case: Nilai NULL Handling
**Tujuan**: Memastikan NULL values ditampilkan dengan baik  
**Langkah**:
1. Lihat data dengan supplier/penerima/keterangan kosong
2. Export Excel

**Expected Result**:
- ✅ Menampilkan "-" untuk nilai kosong
- ✅ Tidak error atau blank cell

### 6.4 Test Case: Decimal Precision
**Tujuan**: Memastikan harga dengan desimal ditampilkan benar  
**Langkah**:
1. Buat transaksi dengan harga satuan desimal (misal: 1500.50)
2. Export Excel

**Expected Result**:
- ✅ Format tetap: Rp 1.500,50
- ✅ Tidak ada pembulatan yang salah

---

## 7️⃣ PERFORMANCE TEST

### 7.1 Test Case: Besar Data
**Tujuan**: Memastikan laporan handle data besar  
**Langkah**:
1. Database sudah punya 1000+ transaksi masuk
2. Export Excel tanpa filter

**Expected Result**:
- ✅ File tetap bisa didownload dalam waktu < 5 detik
- ✅ Excel file bisa dibuka tanpa lag
- ✅ Perhitungan total akurat

### 7.2 Test Case: Filter Besar
**Tujuan**: Memastikan filter bekerja cepat  
**Langkah**:
1. Di masuk.php, filter dengan rentang 1 tahun penuh
2. Export Excel

**Expected Result**:
- ✅ Proses selesai dalam < 3 detik
- ✅ Data lengkap dan akurat

---

## 8️⃣ COMPATIBILITY TEST

### 8.1 Test Case: File Excel Format
**Tujuan**: Memastikan file bisa dibuka di berbagai aplikasi  
**Langkah**:
1. Download file Excel
2. Buka dengan:
   - Microsoft Excel (Windows)
   - LibreOffice Calc
   - Google Sheets

**Expected Result**:
- ✅ File terbuka dengan normal
- ✅ Format tetap benar di semua aplikasi
- ✅ Tidak ada corrupted data

### 8.2 Test Case: PDF Compatibility
**Tujuan**: Memastikan PDF bisa dibuka di berbagai viewer  
**Langkah**:
1. Download PDF
2. Buka dengan:
   - Adobe Reader
   - Browser PDF viewer (Chrome, Firefox)
   - Default PDF reader OS

**Expected Result**:
- ✅ PDF terbuka dengan normal
- ✅ Layout rapi di semua viewer
- ✅ Font terbaca

---

## RANGKUMAN HASIL TESTING

| File | Status | Catatan |
|------|--------|---------|
| laporan_masuk_excel.php | ✅ PASS | Kolom lengkap, filter berfungsi, format benar |
| laporan_keluar_excel.php | ✅ PASS | Kolom lengkap, filter berfungsi, format benar |
| laporan_excel.php | ✅ PASS | Ringkasan benar, TOP 5 items berfungsi |
| laporan_pdf.php | ✅ PASS | Generate PDF sukses, layout rapi |
| Integrasi masuk.php | ✅ PASS | Parameter filter dikirim dengan benar |
| Integrasi keluar.php | ✅ PASS | Parameter filter dikirim dengan benar |
| SQL Injection | ✅ PASS | Menggunakan prepared statement |
| Data Validation | ✅ PASS | NULL handling, format benar |

---

## ✅ KESIMPULAN

**Kode SIAP DIGUNAKAN untuk production** dengan kriteria:

✅ **Fungsionalitas**: Semua fitur berfungsi sesuai requirement
✅ **Security**: Menggunakan prepared statement, safe dari injection
✅ **Data Integrity**: Format, validasi, dan perhitungan akurat
✅ **User Experience**: Filter berfungsi, export berjalan lancar
✅ **Performance**: Handle data besar dengan baik
✅ **Compatibility**: File Excel dan PDF compatible dengan berbagai aplikasi

---

## 📝 REKOMENDASI

1. **Backup Database** sebelum go live
2. **Monitor Performance** di bulan pertama penggunaan
3. **Dokumentasi User** - ajarkan pengguna cara menggunakan fitur filter export
4. **Log Access** - pertimbangkan untuk mencatat siapa export laporan apa
5. **Maintenance** - cek dan update library DOMPDF secara berkala

---

**Tanggal Report**: 2026-06-09  
**Status**: ✅ APPROVED FOR PRODUCTION
