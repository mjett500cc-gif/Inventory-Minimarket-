# 📱 PANDUAN PENGGUNA - FITUR LAPORAN & EXPORT

**Aplikasi**: Inventory Minimarket Mjet  
**Versi**: 1.0  
**Tanggal**: 2026-06-09

---

## 🎯 DAFTAR ISI

1. [Laporan Barang Masuk](#laporan-barang-masuk)
2. [Laporan Barang Keluar](#laporan-barang-keluar)
3. [Laporan Inventory Ringkasan](#laporan-inventory-ringkasan)
4. [Tips & Trik](#tips--trik)

---

## 📥 LAPORAN BARANG MASUK

### Akses Halaman

1. Login ke aplikasi
2. Klik menu **Barang Masuk** di sidebar
3. Anda akan melihat daftar semua transaksi barang masuk

### Filter & Pencarian

#### Cari Berdasarkan Keyword

```
Gunakan search box: "Cari no transaksi, barang, supplier..."
```

**Bisa mencari:**
- ✅ Nomor Transaksi (contoh: BM-001)
- ✅ Nama Barang (contoh: "Mie Instan")
- ✅ Supplier (contoh: "PT ABC Distributor")
- ✅ Keterangan (contoh: "Urgent")

**Cara:**
1. Ketik keyword di search box
2. Tekan Enter atau klik tombol Filter
3. Sistem akan menampilkan hasil yang cocok

#### Filter Berdasarkan Tanggal

```
Ada 2 field:
- "Dari": tanggal awal
- "Sampai": tanggal akhir
```

**Cara:**
1. Klik field "Dari" → pilih tanggal mulai
2. Klik field "Sampai" → pilih tanggal akhir
3. Klik tombol **Filter**
4. Data akan ditampilkan untuk rentang tanggal tersebut

#### Kombinasi Filter

Anda bisa menggabungkan pencarian dan tanggal:

```
Contoh: Cari "PT ABC" dalam rentang "01 Januari - 31 Januari"
→ Hanya transaksi dari PT ABC bulan Januari yang ditampilkan
```

### Export ke Excel

#### Cara Export

1. **Tanpa Filter:**
   - Langsung klik tombol **Export Excel** (di atas)
   - File `Laporan_Barang_Masuk.xls` akan diunduh

2. **Dengan Filter:**
   - Isi pencarian dan/atau tanggal
   - Klik **Filter**
   - Klik **Export Excel**
   - File akan diunduh dengan data yang sudah ter-filter

#### Apa yang Ada di File Excel

| Kolom | Isi | Contoh |
|-------|-----|--------|
| No | Nomor urut | 1, 2, 3... |
| No Transaksi | ID transaksi | BM-20240501-001 |
| Tanggal Masuk | Kapan barang masuk | 01-05-2024 |
| Kode Barang | Kode identitas barang | KB-001 |
| Nama Barang | Nama barang | Mie Instan Merek X |
| Jumlah | Berapa banyak + satuan (merged) | 10 box, 5 karton, 100 pcs |
| Harga Satuan | Harga per unit | Rp 45.000 |
| Total Harga | Jumlah × Harga | Rp 4.500.000 |
| Supplier | Siapa yang kirim | PT ABC Distributor |

#### Catatan Penting

- ✅ File Excel bisa dibuka di Microsoft Excel, Google Sheets, LibreOffice
- ✅ Total Nilai Barang Masuk sudah dihitung otomatis
- ✅ Tanggal selalu format: DD-MM-YYYY
- ✅ Harga selalu format: Rp X.XXX.XXX,XX

---

## 📤 LAPORAN BARANG KELUAR

### Akses Halaman

1. Login ke aplikasi
2. Klik menu **Barang Keluar** di sidebar
3. Anda akan melihat daftar semua transaksi barang keluar

### Filter & Pencarian

#### Cari Berdasarkan Keyword

```
Gunakan search box: "Cari no transaksi, barang, tujuan..."
```

**Bisa mencari:**
- ✅ Nomor Transaksi (contoh: BK-001)
- ✅ Nama Barang (contoh: "Mie Instan")
- ✅ Tujuan (contoh: "Toko Cabang A")
- ✅ Keterangan (contoh: "Pengiriman")

#### Filter Berdasarkan Tanggal

Sama seperti laporan masuk:
1. Isi "Dari" dan "Sampai"
2. Klik **Filter**

#### Kombinasi Filter

Bisa menggabungkan pencarian dan tanggal seperti pada laporan masuk.

### Export ke Excel

#### Cara Export

1. **Tanpa Filter:**
   - Klik **Export Excel**
   - File `Laporan_Barang_Keluar.xls` diunduh

2. **Dengan Filter:**
   - Isi filter
   - Klik **Filter**
   - Klik **Export Excel**

#### Apa yang Ada di File Excel

| Kolom | Isi | Contoh |
|-------|-----|--------|
| No | Nomor urut | 1, 2, 3... |
| No Transaksi | ID transaksi | BK-20240501-001 |
| Tanggal Keluar | Kapan barang keluar | 01-05-2024 |
| Kode Barang | Kode identitas barang | KB-001 |
| Nama Barang | Nama barang | Mie Instan Merek X |
| Jumlah | Berapa banyak + satuan (merged) | 10 box, 5 karton, 100 pcs |
| Harga Satuan | Harga per unit | Rp 45.000 |
| Total Harga | Jumlah × Harga | Rp 2.250.000 |
| Tujuan | Kemana barang dikirim | Toko Cabang A |
| Penerima | Siapa yang terima | Budi Santoso |

#### Catatan Penting

- ✅ Total Nilai Barang Keluar sudah dihitung otomatis
- ✅ Jika Penerima kosong, ditampilkan "-"
- ✅ Semua format sama seperti laporan masuk

---

## 📊 LAPORAN INVENTORY RINGKASAN

### Akses Halaman

1. Login ke aplikasi
2. Klik menu **Laporan** di sidebar
3. Anda akan melihat dashboard dengan ringkasan

### Filter Laporan

#### Pilih Bulan dan Tahun

```
Ada dropdown untuk memilih:
- Bulan: January, February, ... December
- Tahun: 2025, 2026, 2027
```

**Cara:**
1. Pilih bulan yang diinginkan
2. Pilih tahun
3. Klik **Filter**
4. Dashboard akan update dengan data bulan tersebut

### Apa yang Ditampilkan

#### 📈 Ringkasan Stok Saat Ini

- **Total Jenis Barang**: Berapa banyak jenis barang yang aktif
- **Total Stok**: Total jumlah seluruh barang
- **Nilai Stok (Modal)**: Total nilai barang dihitung dari harga beli
- **Stok Menipis**: Berapa barang yang sudah hampir habis

#### 💼 Barang Masuk Bulan Ini

Menunjukkan transaksi masuk dalam bulan yang dipilih:
- Jumlah transaksi (berapa kali ada barang masuk)
- Jumlah item total yang masuk
- Total nilai barang yang masuk

#### 📦 Barang Keluar Bulan Ini

Menunjukkan transaksi keluar dalam bulan yang dipilih:
- Jumlah transaksi (berapa kali ada barang keluar)
- Jumlah item total yang keluar
- Total nilai barang yang keluar

#### 🏷️ Stok per Kategori

Tabel menunjukkan:
- Nama kategori (contoh: "Makanan", "Minuman")
- Jenis barang dalam kategori
- Total stok
- Total nilai stok

#### 🔥 Barang Paling Sering Keluar

Menunjukkan TOP 5 barang yang paling banyak keluar bulan ini:
- Kode barang
- Nama barang
- Total item yang keluar

Berguna untuk mengetahui produk favorit pelanggan.

#### ⚠️ Barang Stok Menipis

Jika ada barang yang stoknya di bawah minimum:
- Kode barang
- Nama barang
- Kategori
- Stok saat ini
- Stok minimum
- Status (Habis atau Menipis)

**Action**: Segera pesan kembali barang yang ditampilkan di sini!

### Export ke Excel

#### Cara Export

1. Pilih bulan dan tahun
2. Klik **Filter**
3. Klik tombol **Excel** (di atas)
4. File `Laporan_Inventory_MM_YYYY.xls` diunduh

#### Apa yang Ada di File Excel

File akan berisi semua section yang ditampilkan di halaman:

1. **Ringkasan Inventory**
   - Total barang, stok, nilai, jumlah menipis

2. **Transaksi Bulan Ini**
   - Data masuk: transaksi, qty, nilai
   - Data keluar: transaksi, qty, nilai

3. **Stok Per Kategori**
   - Detail stok untuk setiap kategori

4. **Barang Stok Menipis** (jika ada)
   - Daftar barang yang perlu di-restock

5. **Barang Paling Sering Keluar** (jika ada)
   - TOP barang keluar

### Export ke PDF

#### Cara Export PDF

1. Pilih bulan dan tahun
2. Klik **Filter**
3. Klik tombol **PDF** (di atas)
4. File PDF akan di-generate dan dibuka/diunduh

#### Keuntungan PDF

- ✅ Format lebih rapi dan profesional
- ✅ Cocok untuk dicetak
- ✅ Bisa dikirim via email
- ✅ Ukuran file lebih kecil

#### Catatan

- PDF otomatis dalam format Landscape (horizontal)
- Cocok untuk kertas A4
- Bisa dibuka dengan Adobe Reader atau browser

---

## 💡 TIPS & TRIK

### Tip 1: Export Rutin

```
Setiap akhir bulan:
1. Buka halaman Laporan
2. Pilih bulan sebelumnya
3. Klik Filter
4. Export Excel untuk arsip
5. Simpan dengan nama: "Laporan_Januari_2024.xls"
```

### Tip 2: Cek Barang Menipis

```
Setiap hari (atau minimal seminggu sekali):
1. Buka halaman Laporan
2. Lihat section "Barang Stok Menipis"
3. Jika ada, segera order ke supplier
4. Catat barang apa yang perlu diorder
```

### Tip 3: Analisis Produk Populer

```
Setiap bulan:
1. Buka halaman Laporan
2. Lihat "Barang Paling Sering Keluar"
3. Pastikan stok barang-barang ini selalu cukup
4. Pertimbangkan menambah kuantitas di gudang
```

### Tip 4: Filter Spesifik untuk Analisis

```
Contoh analisis supplier:
1. Buka halaman Barang Masuk
2. Search "PT ABC Distributor"
3. Atur tanggal range (misal 3 bulan terakhir)
4. Export Excel
5. Analisis: berapa sering order, total nilai, ketepatan waktu

Contoh analisis pengeluaran ke toko tertentu:
1. Buka halaman Barang Keluar
2. Search "Toko Cabang A"
3. Atur tanggal range
4. Export Excel
5. Analisis: volume penjualan, trending
```

### Tip 5: Backup Rutin

```
Rekomendasinya:
- Export Excel laporan bulanan
- Simpan di folder Backup
- Jika perlu data historis, bisa cek file-file lama
- Lebih aman daripada hanya mengandalkan database
```

### Tip 6: Print Report

```
Untuk hasil cetak terbaik:
1. Export ke PDF
2. Buka dengan browser (Chrome, Firefox)
3. Print dengan Ctrl+P
4. Pilih printer
5. Kertas A4 Landscape untuk hasil optimal
```

---

## ❓ PERTANYAAN UMUM

### Q: Bagaimana jika data tidak tampil saat export?

**A:** Kemungkinan:
1. Filter terlalu ketat (tidak ada data yang cocok)
2. Tanggal yang dipilih tidak ada transaksi
3. Keyword pencarian tidak cocok dengan data

**Solusi:**
- Hapus filter (klik "Reset" jika ada)
- Coba tanggal yang lain
- Coba keyword yang berbeda

### Q: File Excel rusak atau tidak bisa dibuka?

**A:** Coba:
1. Gunakan aplikasi lain (Google Sheets, LibreOffice)
2. Clear browser cache (Ctrl+Shift+Delete)
3. Download ulang file
4. Hubungi administrator jika tetap error

### Q: PDF tidak bisa dibuka?

**A:** Coba:
1. Install Adobe Reader terbaru
2. Gunakan browser (Chrome, Firefox) untuk buka PDF
3. Hubungi administrator jika tetap error

### Q: Bagaimana jika ingin export semua tahun?

**A:** Saat ini sistem per-bulan. Untuk export semua tahun:
1. Export setiap bulannya
2. Gabungkan file Excel secara manual
3. Atau hubungi administrator untuk laporan kustom

### Q: Apakah data export bisa diubah?

**A:** Excel file bisa diubah untuk kebutuhan lokal, tapi:
- Jangan ubah data asli sebelum disimpan
- Simpan sebagai file baru dengan nama berbeda
- Pastikan total masih akurat

### Q: Berapa lama waktu proses export?

**A:** 
- Excel: biasanya instan (< 1 detik)
- PDF: 1-3 detik tergantung jumlah data
- Jika lebih lama, kemungkinan server sibuk

---

## 📞 HUBUNGI SUPPORT

Jika ada kendala atau pertanyaan:

- **Email**: admin@minimarketmjet.com
- **Phone**: +62-XXX-XXX-XXXX
- **Jam Kerja**: Senin-Jumat 09:00 - 17:00

---

**Versi**: 1.0  
**Terakhir Diupdate**: 2026-06-09  
**Status**: Approved for Users
