<?php
require_once 'config/database.php';

if (isLoggedIn()) redirect('dashboard.php');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = 'Username dan Password harus diisi.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND aktif = 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['nama_lengkap'] = $user['nama_lengkap'];
            $_SESSION['role'] = $user['role'];

            redirect('dashboard.php');
        } else {
            $error = 'Username atau Password salah.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Inventory Minimarket Mjet</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;

    background:linear-gradient(
    135deg,
    #2563eb,
    #1d4ed8,
    #16a34a
    );
}

.login-container{
    width:100%;
    max-width:450px;
    padding:20px;
}

.login-card{
    background:rgba(255,255,255,0.95);
    backdrop-filter:blur(12px);

    border-radius:25px;
    padding:40px;

    box-shadow:
    0 20px 50px rgba(0,0,0,.15);

    animation:fadeIn .8s ease;
}

@keyframes fadeIn{
    from{
        opacity:0;
        transform:translateY(20px);
    }
    to{
        opacity:1;
        transform:translateY(0);
    }
}

.login-header{
    text-align:center;
    margin-bottom:30px;
}

.login-icon{
    width:90px;
    height:90px;

    margin:auto;
    margin-bottom:15px;

    border-radius:50%;

    background:linear-gradient(
    135deg,
    #2563eb,
    #16a34a
    );

    display:flex;
    justify-content:center;
    align-items:center;

    color:white;
    font-size:38px;
}

.login-header h1{
    color:#1e293b;
    font-size:28px;
    margin-bottom:5px;
}

.login-header p{
    color:#64748b;
    font-size:14px;
}

.alert{
    background:#fee2e2;
    color:#dc2626;
    padding:12px;
    border-radius:10px;
    margin-bottom:20px;
    font-size:14px;
}

.form-group{
    margin-bottom:20px;
}

.form-group label{
    display:block;
    margin-bottom:8px;
    font-weight:500;
    color:#334155;
}

.input-group{
    position:relative;
}

.input-group i.left{
    position:absolute;
    left:15px;
    top:50%;
    transform:translateY(-50%);
    color:#94a3b8;
}

.form-control{
    width:100%;
    padding:14px 45px;
    border:1px solid #cbd5e1;
    border-radius:12px;
    font-size:14px;

    transition:.3s;
}

.form-control:focus{
    outline:none;
    border-color:#2563eb;
    box-shadow:0 0 0 4px rgba(37,99,235,.15);
}

.toggle-password{
    position:absolute;
    right:15px;
    top:50%;
    transform:translateY(-50%);
    cursor:pointer;
    color:#64748b;
}

.btn-login{
    width:100%;
    border:none;

    padding:14px;

    border-radius:12px;

    background:linear-gradient(
    135deg,
    #2563eb,
    #16a34a
    );

    color:white;
    font-size:15px;
    font-weight:600;

    cursor:pointer;

    transition:.3s;
}

.btn-login:hover{
    transform:translateY(-2px);

    box-shadow:
    0 10px 25px rgba(37,99,235,.25);
}

.footer-text{
    text-align:center;
    margin-top:20px;
    color:#64748b;
    font-size:12px;
}

@media(max-width:480px){

    .login-card{
        padding:25px;
    }

    .login-header h1{
        font-size:22px;
    }

}

</style>

</head>

<body>

<div class="login-container">

    <div class="login-card">

        <div class="login-header">

            <div class="login-icon">
                <i class="fas fa-store"></i>
            </div>

            <h1>INVENTORY MJETT</h1>

            <p>Sistem Inventory Minimarket Mjet</p>

        </div>

        <?php if($error): ?>
        <div class="alert">
            <i class="fas fa-exclamation-circle"></i>
            <?= sanitize($error) ?>
        </div>
        <?php endif; ?>

        <form method="POST">

            <div class="form-group">

                <label>Username</label>

                <div class="input-group">

                    <i class="fas fa-user left"></i>

                    <input
                    type="text"
                    name="username"
                    class="form-control"
                    placeholder="Masukkan Username"
                    value="<?= sanitize($_POST['username'] ?? '') ?>"
                    required>

                </div>

            </div>

            <div class="form-group">

                <label>Password</label>

                <div class="input-group">

                    <i class="fas fa-lock left"></i>

                    <input
                    type="password"
                    id="password"
                    name="password"
                    class="form-control"
                    placeholder="Masukkan Password"
                    required>

                    <span class="toggle-password" onclick="togglePassword()">
                        <i id="eyeIcon" class="fas fa-eye"></i>
                    </span>

                </div>

            </div>

            <button type="submit" class="btn-login">
                <i class="fas fa-sign-in-alt"></i>
                Masuk ke Sistem
            </button>

        </form>

        <div class="footer-text">
            © <?= date('Y') ?> Inventory Minimarket Mjet
        </div>

    </div>

</div>

<script>

function togglePassword(){

    let password = document.getElementById('password');
    let eyeIcon = document.getElementById('eyeIcon');

    if(password.type === 'password'){
        password.type = 'text';
        eyeIcon.classList.remove('fa-eye');
        eyeIcon.classList.add('fa-eye-slash');
    }else{
        password.type = 'password';
        eyeIcon.classList.remove('fa-eye-slash');
        eyeIcon.classList.add('fa-eye');
    }

}

</script>

</body>
</html>