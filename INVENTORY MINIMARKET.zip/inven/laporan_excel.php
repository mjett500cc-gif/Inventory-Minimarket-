<?php
require_once 'config/database.php';
requireLogin();

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Laporan_Inventory.xls");

$bulan = $_GET['bulan'] ?? date('m');
$tahun = $_GET['tahun'] ?? date('Y');

// Ringkasan
$stmt = $pdo->query("SELECT COUNT(*) as cnt FROM barang WHERE aktif = 1");
$total_barang = $stmt->fetch()['cnt'];

$stmt = $pdo->query("SELECT COALESCE(SUM(stok),0) as total FROM barang WHERE aktif = 1");
$total_stok = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COALESCE(SUM(stok * harga_beli),0) as total FROM barang WHERE aktif = 1");
$nilai_stok = $stmt->fetch()['total'];

$stmt = $pdo->prepare("
    SELECT COUNT(*) as cnt,
           COALESCE(SUM(jumlah),0) as qty,
           COALESCE(SUM(total_harga),0) as nilai
    FROM barang_masuk
    WHERE MONTH(tanggal_masuk)=?
    AND YEAR(tanggal_masuk)=?
");
$stmt->execute([$bulan,$tahun]);
$masuk = $stmt->fetch();

$stmt = $pdo->prepare("
    SELECT COUNT(*) as cnt,
           COALESCE(SUM(jumlah),0) as qty,
           COALESCE(SUM(total_harga),0) as nilai
    FROM barang_keluar
    WHERE MONTH(tanggal_keluar)=?
    AND YEAR(tanggal_keluar)=?
");
$stmt->execute([$bulan,$tahun]);
$keluar = $stmt->fetch();

$per_kategori = $pdo->query("
    SELECT k.nama_kategori,
           COUNT(b.id) as jumlah_item,
           COALESCE(SUM(b.stok),0) as total_stok,
           COALESCE(SUM(b.stok*b.harga_beli),0) as nilai_stok
    FROM kategori k
    LEFT JOIN barang b
        ON k.id=b.kategori_id
        AND b.aktif=1
    GROUP BY k.id
")->fetchAll();

$stok_menipis = $pdo->query("
    SELECT b.kode_barang,
           b.nama_barang,
           k.nama_kategori,
           b.stok,
           b.stok_minimum
    FROM barang b
    LEFT JOIN kategori k ON b.kategori_id=k.id
    WHERE b.stok <= b.stok_minimum
    AND b.aktif=1
")->fetchAll();

$populer = $pdo->prepare("
    SELECT b.kode_barang,
           b.nama_barang,
           SUM(bk.jumlah) as total_keluar
    FROM barang_keluar bk
    JOIN barang b ON bk.barang_id = b.id
    WHERE MONTH(bk.tanggal_keluar)=?
    AND YEAR(bk.tanggal_keluar)=?
    GROUP BY bk.barang_id
    ORDER BY total_keluar DESC
    LIMIT 5
");
$populer->execute([$bulan,$tahun]);
$barang_populer = $populer->fetchAll();
?>

<h2>LAPORAN INVENTORY MINIMARKET Mjet</h2>
<p>Periode : <?= date('F Y', mktime(0,0,0,$bulan,1,$tahun)) ?></p>

<br>

<table border="1">
    <tr style="background:#cccccc;">
        <th colspan="2">RINGKASAN INVENTORY</th>
    </tr>
    <tr>
        <td>Total Jenis Barang</td>
        <td><?= $total_barang ?></td>
    </tr>
    <tr>
        <td>Total Stok</td>
        <td><?= number_format($total_stok) ?></td>
    </tr>
    <tr>
        <td>Nilai Stok</td>
        <td>Rp <?= number_format($nilai_stok, 0, ',', '.') ?></td>
    </tr>
</table>

<br><br>

<table border="1">
    <tr style="background:#cccccc;">
        <th colspan="4">TRANSAKSI BULAN INI</th>
    </tr>
    <tr>
        <th></th>
        <th>Transaksi</th>
        <th>Jumlah Item</th>
        <th>Nilai</th>
    </tr>
    <tr>
        <td>Barang Masuk</td>
        <td><?= $masuk['cnt'] ?></td>
        <td><?= number_format($masuk['qty']) ?></td>
        <td>Rp <?= number_format($masuk['nilai'], 0, ',', '.') ?></td>
    </tr>
    <tr>
        <td>Barang Keluar</td>
        <td><?= $keluar['cnt'] ?></td>
        <td><?= number_format($keluar['qty']) ?></td>
        <td>Rp <?= number_format($keluar['nilai'], 0, ',', '.') ?></td>
    </tr>
</table>

<br><br>

<table border="1">
    <tr style="background:#cccccc;">
        <th colspan="4">STOK PER KATEGORI</th>
    </tr>
    <tr>
        <th>Kategori</th>
        <th>Jumlah Item</th>
        <th>Total Stok</th>
        <th>Nilai Stok</th>
    </tr>

    <?php foreach($per_kategori as $row): ?>
    <tr>
        <td><?= $row['nama_kategori'] ?></td>
        <td><?= $row['jumlah_item'] ?></td>
        <td><?= number_format($row['total_stok']) ?></td>
        <td>Rp <?= number_format($row['nilai_stok'], 0, ',', '.') ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<br><br>

<table border="1">
    <tr style="background:#ff9999;">
        <th colspan="5">BARANG STOK MENIPIS</th>
    </tr>
    <tr>
        <th>Kode</th>
        <th>Nama Barang</th>
        <th>Kategori</th>
        <th>Stok</th>
        <th>Stok Minimum</th>
    </tr>

    <?php foreach($stok_menipis as $row): ?>
    <tr>
        <td><?= $row['kode_barang'] ?></td>
        <td><?= $row['nama_barang'] ?></td>
        <td><?= $row['nama_kategori'] ?></td>
        <td><?= $row['stok'] ?></td>
        <td><?= $row['stok_minimum'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<br><br>

<?php if (!empty($barang_populer)): ?>
<table border="1">
    <tr style="background:#fff3cd;">
        <th colspan="3">BARANG PALING SERING KELUAR</th>
    </tr>
    <tr>
        <th>Kode Barang</th>
        <th>Nama Barang</th>
        <th>Total Keluar</th>
    </tr>

    <?php foreach($barang_populer as $row): ?>
    <tr>
        <td><?= $row['kode_barang'] ?></td>
        <td><?= $row['nama_barang'] ?></td>
        <td><?= $row['total_keluar'] ?> item</td>
    </tr>
    <?php endforeach; ?>
</table>
<?php endif; ?>