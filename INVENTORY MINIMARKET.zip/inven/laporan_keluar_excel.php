<?php
require_once 'config/database.php';
requireLogin();

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Laporan_Barang_Keluar.xls");

// Support filtering
$search = $_GET['q'] ?? '';
$tanggal_dari = $_GET['dari'] ?? '';
$tanggal_sampai = $_GET['sampai'] ?? '';

$where = ["1=1"];
$params = [];

if ($search) {
    $where[] = "(bk.no_transaksi LIKE ? OR b.nama_barang LIKE ? OR bk.tujuan LIKE ? OR bk.keterangan LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($tanggal_dari) {
    $where[] = "bk.tanggal_keluar >= ?";
    $params[] = $tanggal_dari;
}
if ($tanggal_sampai) {
    $where[] = "bk.tanggal_keluar <= ?";
    $params[] = $tanggal_sampai;
}

$where_sql = implode(' AND ', $where);

$stmt = $pdo->prepare("
    SELECT bk.*, b.kode_barang, b.nama_barang, b.satuan
    FROM barang_keluar bk
    JOIN barang b ON bk.barang_id = b.id
    WHERE $where_sql
    ORDER BY bk.tanggal_keluar DESC
");

$stmt->execute($params);
$data = $stmt->fetchAll();

$total_keluar = 0;
?>

<table border="1">
    <tr>
        <th colspan="10" style="background:#D9EAD3;">
            LAPORAN BARANG KELUAR - INVENTORY MINIMARKET Mjet
        </th>
    </tr>

    <tr>
        <th>No</th>
        <th>No Transaksi</th>
        <th>Tanggal Keluar</th>
        <th>Kode Barang</th>
        <th>Nama Barang</th>
        <th>Jumlah</th>
        <th>Harga Satuan</th>
        <th>Total Harga</th>
        <th>Tujuan</th>
        <th>Penerima</th>
    </tr>

    <?php $no = 1; ?>

    <?php foreach($data as $row): ?>

    <?php $total_keluar += $row['total_harga']; ?>

    <tr>
        <td><?= $no++ ?></td>
        <td><?= $row['no_transaksi'] ?></td>
        <td><?= date('d-m-Y', strtotime($row['tanggal_keluar'])) ?></td>
        <td><?= $row['kode_barang'] ?></td>
        <td><?= $row['nama_barang'] ?></td>
        <td><?= $row['jumlah'] ?> <?= $row['satuan'] ?></td>
        <td>Rp <?= number_format($row['harga_satuan'], 0, ',', '.') ?></td>
        <td>Rp <?= number_format($row['total_harga'], 0, ',', '.') ?></td>
        <td><?= $row['tujuan'] ?? '-' ?></td>
        <td><?= $row['penerima'] ?? '-' ?></td>
    </tr>

    <?php endforeach; ?>

    <tr>
        <td colspan="7">
            <strong>Total Nilai Barang Keluar</strong>
        </td>
        <td colspan="3">
            <strong>
                Rp <?= number_format($total_keluar,0,',','.') ?>
            </strong>
        </td>
    </tr>

</table>