<?php
require_once 'config/database.php';
requireLogin();

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Laporan_Barang_Masuk.xls");

// Support filtering
$search = $_GET['q'] ?? '';
$tanggal_dari = $_GET['dari'] ?? '';
$tanggal_sampai = $_GET['sampai'] ?? '';

$where = ["1=1"];
$params = [];

if ($search) {
    $where[] = "(bm.no_transaksi LIKE ? OR b.nama_barang LIKE ? OR bm.supplier LIKE ? OR bm.keterangan LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($tanggal_dari) {
    $where[] = "bm.tanggal_masuk >= ?";
    $params[] = $tanggal_dari;
}
if ($tanggal_sampai) {
    $where[] = "bm.tanggal_masuk <= ?";
    $params[] = $tanggal_sampai;
}

$where_sql = implode(' AND ', $where);

$stmt = $pdo->prepare("
    SELECT bm.*, b.kode_barang, b.nama_barang, b.satuan
    FROM barang_masuk bm
    JOIN barang b ON bm.barang_id = b.id
    WHERE $where_sql
    ORDER BY bm.tanggal_masuk DESC
");

$stmt->execute($params);
$data = $stmt->fetchAll();

$total_masuk = 0;
?>

<table border="1">
    <tr>
        <th colspan="9" style="background:#D9EAD3;">
            LAPORAN BARANG MASUK - INVENTORY MINIMARKET Mjet
        </th>
    </tr>

    <tr>
        <th>No</th>
        <th>No Transaksi</th>
        <th>Tanggal Masuk</th>
        <th>Kode Barang</th>
        <th>Nama Barang</th>
        <th>Jumlah</th>
        <th>Harga Satuan</th>
        <th>Total Harga</th>
        <th>Supplier</th>
    </tr>

    <?php $no = 1; ?>

    <?php foreach($data as $row): ?>

    <?php $total_masuk += $row['total_harga']; ?>

    <tr>
        <td><?= $no++ ?></td>
        <td><?= $row['no_transaksi'] ?></td>
        <td><?= date('d-m-Y', strtotime($row['tanggal_masuk'])) ?></td>
        <td><?= $row['kode_barang'] ?></td>
        <td><?= $row['nama_barang'] ?></td>
        <td><?= $row['jumlah'] ?> <?= $row['satuan'] ?></td>
        <td>
            Rp <?= number_format($row['harga_satuan'], 0, ',', '.') ?>
        </td>
        <td>
            Rp <?= number_format($row['total_harga'], 0, ',', '.') ?>
        </td>
        <td><?= $row['supplier'] ?? '-' ?></td>
    </tr>

    <?php endforeach; ?>

    <tr>
        <td colspan="7">
            <strong>Total Nilai Barang Masuk</strong>
        </td>
        <td colspan="2">
            <strong>
                Rp <?= number_format($total_masuk, 0, ',', '.') ?>
            </strong>
        </td>
    </tr>

</table>
<?php
if (empty($data)) {
    echo '<p style="font-style:italic;color:#999;">Tidak ada data untuk ditampilkan</p>';
}
?>