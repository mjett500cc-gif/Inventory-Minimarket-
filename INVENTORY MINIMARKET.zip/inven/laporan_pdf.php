<?php

require_once 'config/database.php';
requireLogin();

require_once 'vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

$bulan = $_GET['bulan'] ?? date('m');
$tahun = $_GET['tahun'] ?? date('Y');

/*
|--------------------------------------------------------------------------
| RINGKASAN
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("SELECT COUNT(*) as cnt FROM barang WHERE aktif = 1");
$total_barang = $stmt->fetch()['cnt'];

$stmt = $pdo->query("SELECT COALESCE(SUM(stok),0) as total FROM barang WHERE aktif = 1");
$total_stok = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COALESCE(SUM(stok * harga_beli),0) as total FROM barang WHERE aktif = 1");
$nilai_stok = $stmt->fetch()['total'];

/*
|--------------------------------------------------------------------------
| BARANG MASUK BULAN INI
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
SELECT COUNT(*) as cnt,
       COALESCE(SUM(jumlah),0) as qty,
       COALESCE(SUM(total_harga),0) as nilai
FROM barang_masuk
WHERE MONTH(tanggal_masuk)=?
AND YEAR(tanggal_masuk)=?
");

$stmt->execute([$bulan,$tahun]);
$masuk_bulan = $stmt->fetch();

/*
|--------------------------------------------------------------------------
| BARANG KELUAR BULAN INI
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
SELECT COUNT(*) as cnt,
       COALESCE(SUM(jumlah),0) as qty,
       COALESCE(SUM(total_harga),0) as nilai
FROM barang_keluar
WHERE MONTH(tanggal_keluar)=?
AND YEAR(tanggal_keluar)=?
");

$stmt->execute([$bulan,$tahun]);
$keluar_bulan = $stmt->fetch();

/*
|--------------------------------------------------------------------------
| STOK PER KATEGORI
|--------------------------------------------------------------------------
*/

$per_kategori = $pdo->query("
SELECT
    k.nama_kategori,
    COUNT(b.id) as jumlah_item,
    COALESCE(SUM(b.stok),0) as total_stok,
    COALESCE(SUM(b.stok * b.harga_beli),0) as nilai_stok
FROM kategori k
LEFT JOIN barang b
ON k.id = b.kategori_id
AND b.aktif = 1
GROUP BY k.id
ORDER BY total_stok DESC
")->fetchAll();

/*
|--------------------------------------------------------------------------
| STOK MENIPIS
|--------------------------------------------------------------------------
*/

$stok_menipis = $pdo->query("
SELECT
    b.*,
    k.nama_kategori
FROM barang b
LEFT JOIN kategori k
ON b.kategori_id = k.id
WHERE b.stok <= b.stok_minimum
AND b.aktif = 1
ORDER BY b.stok ASC
")->fetchAll();

/*
|--------------------------------------------------------------------------
| BARANG PALING SERING KELUAR
|--------------------------------------------------------------------------
*/

$populer = $pdo->prepare("
SELECT
    b.kode_barang,
    b.nama_barang,
    SUM(bk.jumlah) as total_keluar
FROM barang_keluar bk
JOIN barang b ON bk.barang_id = b.id
WHERE MONTH(bk.tanggal_keluar)=?
AND YEAR(bk.tanggal_keluar)=?
GROUP BY bk.barang_id
ORDER BY total_keluar DESC
LIMIT 5
");

$populer->execute([$bulan,$tahun]);

$barang_populer = $populer->fetchAll();

/*
|--------------------------------------------------------------------------
| HTML PDF
|--------------------------------------------------------------------------
*/

$html = '

<style>

body{
    font-family: DejaVu Sans;
    font-size:11px;
}

table{
    width:100%;
    border-collapse:collapse;
    margin-bottom:15px;
}

th,td{
    border:1px solid #000;
    padding:5px;
}

th{
    background:#eeeeee;
}

.section-title{
    background:#dbeafe;
    padding:8px;
    font-weight:bold;
    margin:10px 0;
}

.text-center{
    text-align:center;
}

</style>

<h1 style="text-align:center;">
LAPORAN INVENTORY MINIMARKET MJET
</h1>

<p style="text-align:center;">
Periode '.$bulan.'/'.$tahun.'
</p>

<div class="section-title">
Ringkasan Inventaris
</div>

<table>
<tr>
<th>Total Barang</th>
<th>Total Stok</th>
<th>Nilai Stok</th>
<th>Stok Menipis</th>
</tr>

<tr>
<td>'.$total_barang.'</td>
<td>'.number_format($total_stok).'</td>
<td>'.rupiah($nilai_stok).'</td>
<td>'.count($stok_menipis).'</td>
</tr>
</table>

<div class="section-title">
Barang Masuk & Keluar
</div>

<table>
<tr>
<th colspan="3">Barang Masuk</th>
<th colspan="3">Barang Keluar</th>
</tr>

<tr>
<th>Transaksi</th>
<th>Qty</th>
<th>Nilai</th>

<th>Transaksi</th>
<th>Qty</th>
<th>Nilai</th>
</tr>

<tr>
<td>'.$masuk_bulan['cnt'].'</td>
<td>'.number_format($masuk_bulan['qty']).'</td>
<td>'.rupiah($masuk_bulan['nilai']).'</td>

<td>'.$keluar_bulan['cnt'].'</td>
<td>'.number_format($keluar_bulan['qty']).'</td>
<td>'.rupiah($keluar_bulan['nilai']).'</td>
</tr>

</table>

<div class="section-title">
Stok Per Kategori
</div>

<table>
<tr>
<th>Kategori</th>
<th>Jenis Barang</th>
<th>Total Stok</th>
<th>Nilai Stok</th>
</tr>
';

/*loop kategori*/

foreach($per_kategori as $pk){

$html .= '
<tr>
<td>'.$pk['nama_kategori'].'</td>
<td>'.$pk['jumlah_item'].'</td>
<td>'.number_format($pk['total_stok']).'</td>
<td>'.rupiah($pk['nilai_stok']).'</td>
</tr>';
}

$html .= '</table>';

/*
|--------------------------------------------------------------------------
| BARANG PALING SERING KELUAR
|--------------------------------------------------------------------------
*/

if (!empty($barang_populer)) {
    $html .= '
    <div class="section-title">
    Barang Paling Sering Keluar
    </div>
    
    <table>
    <tr>
    <th>Kode Barang</th>
    <th>Nama Barang</th>
    <th>Total Keluar</th>
    </tr>
    ';
    
    foreach($barang_populer as $bp) {
        $html .= '
        <tr>
        <td>'.$bp['kode_barang'].'</td>
        <td>'.$bp['nama_barang'].'</td>
        <td>'.$bp['total_keluar'].' item</td>
        </tr>
        ';
    }
    
    $html .= '</table>';
}

/*
|--------------------------------------------------------------------------
| STOK MENIPIS
|--------------------------------------------------------------------------
*/

if (!empty($stok_menipis)) {
    $html .= '
    <div class="section-title">
    Barang Stok Menipis
    </div>
    
    <table>
    <tr>
    <th>Kode</th>
    <th>Nama Barang</th>
    <th>Kategori</th>
    <th>Stok</th>
    <th>Minimum</th>
    </tr>
    ';
    
    foreach($stok_menipis as $s) {
        $html .= '
        <tr>
        <td>'.$s['kode_barang'].'</td>
        <td>'.$s['nama_barang'].'</td>
        <td>'.$s['nama_kategori'].'</td>
        <td>'.$s['stok'].'</td>
        <td>'.$s['stok_minimum'].'</td>
        </tr>
        ';
    }
    
    $html .= '</table>';
}

/*
|--------------------------------------------------------------------------
| GENERATE PDF
|--------------------------------------------------------------------------
*/

$html .= '
<div style="text-align:right;margin-top:20px;">
Dicetak : '.date('d-m-Y H:i:s').'
</div>
';

$options = new Options();
$options->set('defaultFont','DejaVu Sans');

$dompdf = new Dompdf($options);

$dompdf->loadHtml($html);
$dompdf->setPaper('A4','landscape');
$dompdf->render();

$dompdf->stream(
    'Laporan_Inventory_'.$bulan.'_'.$tahun.'.pdf',
    ['Attachment' => true]
);

exit;