```php
<?php
require_once 'config/database.php';
requireLogin();

/*
|--------------------------------------------------------------------------
| STOK PER KATEGORI
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT
        k.nama_kategori,
        COUNT(b.id) AS jumlah_barang,
        COALESCE(SUM(b.stok),0) AS total_stok
    FROM kategori k
    LEFT JOIN barang b
        ON b.kategori_id = k.id
        AND b.aktif = 1
    GROUP BY k.id
    ORDER BY total_stok DESC
");

$stokKategori = $stmt->fetchAll();

/*
|--------------------------------------------------------------------------
| TOTAL STOK
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT COALESCE(SUM(stok),0) AS total_stok
    FROM barang
    WHERE aktif = 1
");

$totalStok = $stmt->fetch()['total_stok'];

$page_title = 'Stok Barang - Inventory Minimarket Mjet';

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<div class="main-content" style="padding-top:8px !important;">
    <div class="page-header">
    <div>
        <h1>Stok Barang</h1>
        <div class="page-header-sub">
            Monitoring stok barang berdasarkan kategori
        </div>
    </div>

    <div class="page-header-actions">
    </div>
</div>

    <!-- Statistik -->
    <div class="stat-grid animate-in">

        <div class="stat-card">
            <div class="stat-card-header">
                <span class="stat-card-label">
                    Total Stok Barang
                </span>

                <div class="stat-card-icon blue">
                    <i class="fas fa-cubes"></i>
                </div>
            </div>

            <div class="stat-card-value">
                <?= number_format($totalStok) ?>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-card-header">
                <span class="stat-card-label">
                    Jumlah Kategori
                </span>

                <div class="stat-card-icon green">
                    <i class="fas fa-tags"></i>
                </div>
            </div>

            <div class="stat-card-value">
                <?= count($stokKategori) ?>
            </div>
        </div>

    </div>

    <!-- Tabel Stok -->
    <div class="card animate-in">

        <div class="card-header">
            <h3>
                <i class="fas fa-chart-pie"></i>
                Stok Barang Per Kategori
            </h3>
        </div>

        <div class="card-body no-pad">

            <table class="table">

                <thead>
                    <tr>
                        <th width="80">No</th>
                        <th>Kategori</th>
                        <th>Jumlah Barang</th>
                        <th>Total Stok</th>
                    </tr>
                </thead>

                <tbody>

                    <?php
                    $no = 1;

                    foreach($stokKategori as $row):
                    ?>

                    <tr>

                        <td><?= $no++ ?></td>

                        <td class="fw-600">
                            <?= htmlspecialchars($row['nama_kategori']) ?>
                        </td>

                        <td>
                            <?= number_format($row['jumlah_barang']) ?>
                        </td>

                        <td>
                            <span class="badge badge-success">
                                <?= number_format($row['total_stok']) ?>
                            </span>
                        </td>

                    </tr>

                    <?php endforeach; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

</body>
</html>
```